import os
from apscheduler.schedulers.blocking import BlockingScheduler
import main

sched = BlockingScheduler()

minutes = 2


# @sched.scheduled_job('interval', minutes=minutes)
# def timed_job():
#     print(f'This job is run every {minutes} minutes.')
#     return main


@sched.scheduled_job('cron', hour=1)
def scheduled_job():
    print('This job is run every weekday at 5pm.')
    main.execute_etl_pipeline(os.environ.get("DOWNLOAD_DIR"))


@sched.scheduled_job('cron', hour=1, minute=30)
def scheduled_job():
    print('This job is run every weekday at 5pm.')
    main.execute_etl_pipeline(os.environ.get("DOWNLOAD_DIR"))


sched.start()


# git add .; git commit -m 'upload'; git push heroku master
# heroku ps:scale clock=1
